import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ShoppingCartTest {

    private ShoppingCart cart;

    @Before
    public void setUp() {
        cart = new ShoppingCart();
    }

    @Test
    public void testCalculateTotalPrice() {
        cart.addToCart(new Book("Book 1", "Author A", 10.99));
        cart.addToCart(new Book("Book 2", "Author B", 12.50));
        assertEquals(23.49, cart.calculateTotalPrice(), 0.01);
    }

    // Similar tests for other methods
}
