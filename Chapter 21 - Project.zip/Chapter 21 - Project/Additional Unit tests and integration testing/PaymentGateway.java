public class PaymentGateway {
    public boolean processPayment(double amount) {
        // Simulate successful payment processing
        // You can integrate with an actual payment gateway here
        return true;
    }
}
