import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.*;

public class OrderPlacementIntegrationTest {

    private ShoppingCart cart;
    private PaymentGateway paymentGateway;

    @Before
    public void setUp() {
        cart = mock(ShoppingCart.class);
        paymentGateway = mock(PaymentGateway.class);
    }

    @Test
    public void testPlaceOrder() {
        // Simulate adding books to the cart
        when(cart.calculateTotalPrice()).thenReturn(50.0);

        // Simulate successful payment
        when(paymentGateway.processPayment(50.0)).thenReturn(true);

        // Create an order
        Order order = new Order(123, cart.getBooks(), 50.0);
        order.placeOrder();

        // Verify interactions
        verify(cart).calculateTotalPrice();
        verify(paymentGateway).processPayment(50.0);
    }
}
