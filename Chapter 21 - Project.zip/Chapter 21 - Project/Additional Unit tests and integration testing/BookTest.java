import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class BookTest {

    @Test
    public void testGetTitle() {
        Book book = new Book("The Great Gatsby", "F. Scott Fitzgerald", 12.99);
        assertEquals("The Great Gatsby", book.getTitle());
    }

    // Similar tests for getAuthor() and getPrice()
}
