import java.util.List;

public class Order {
    private int orderId;
    private List<Book> orderedBooks;
    private double totalAmount;

    public Order(int orderId, List<Book> orderedBooks, double totalAmount) {
        this.orderId = orderId;
        this.orderedBooks = orderedBooks;
        this.totalAmount = totalAmount;
    }

    public void placeOrder() {
        System.out.println("Order placed successfully!");
        System.out.println("Order ID: " + orderId);
        System.out.println("Total Amount: $" + totalAmount);
    }
}
