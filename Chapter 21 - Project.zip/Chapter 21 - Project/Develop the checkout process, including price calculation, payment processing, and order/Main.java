import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ShoppingCart shoppingCart = new ShoppingCart();
        PaymentGateway paymentGateway = new PaymentGateway();

        // Add books to the cart (you can customize this part)
        shoppingCart.addToCart(new Book("Book 1", "Author A", 10.99));
        shoppingCart.addToCart(new Book("Book 2", "Author B", 12.50));

        // Calculate total price
        double totalPrice = shoppingCart.calculateTotalPrice();
        System.out.println("Total Price: $" + totalPrice);

        // Simulate payment processing
        if (paymentGateway.processPayment(totalPrice)) {
            // Create an order
            Order order = new Order(123, shoppingCart.getBooks(), totalPrice);
            order.placeOrder();
            shoppingCart.clearCart();
        } else {
            System.out.println("Payment failed. Please try again.");
        }
    }
}
